heart_disease_app is the main application intended for user use.
The jupiter zip is for the results and testing. 